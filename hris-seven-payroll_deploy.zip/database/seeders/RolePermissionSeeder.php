<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Role;
use App\Models\Permission;

class RolePermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Create Permissions
        $permissions = [
            // Master Data Permissions
            ['name' => 'View Master Data', 'slug' => 'view-master-data', 'module' => 'master-data', 'description' => 'Melihat menu dan data master'],
            ['name' => 'Create Master Data', 'slug' => 'create-master-data', 'module' => 'master-data', 'description' => 'Membuat data master baru'],
            ['name' => 'Edit Master Data', 'slug' => 'edit-master-data', 'module' => 'master-data', 'description' => 'Mengedit data master'],
            ['name' => 'Delete Master Data', 'slug' => 'delete-master-data', 'module' => 'master-data', 'description' => 'Menghapus data master'],

            // Absensi Permissions
            ['name' => 'View Absensi', 'slug' => 'view-absensi', 'module' => 'absensi', 'description' => 'Melihat data absensi'],
            ['name' => 'Create Absensi', 'slug' => 'create-absensi', 'module' => 'absensi', 'description' => 'Membuat data absensi'],
            ['name' => 'Edit Absensi', 'slug' => 'edit-absensi', 'module' => 'absensi', 'description' => 'Mengedit data absensi'],
            ['name' => 'Delete Absensi', 'slug' => 'delete-absensi', 'module' => 'absensi', 'description' => 'Menghapus data absensi'],

            // Proses Gaji Permissions
            ['name' => 'View Proses Gaji', 'slug' => 'view-proses-gaji', 'module' => 'proses-gaji', 'description' => 'Melihat proses gaji'],
            ['name' => 'Create Proses Gaji', 'slug' => 'create-proses-gaji', 'module' => 'proses-gaji', 'description' => 'Membuat proses gaji'],
            ['name' => 'Edit Proses Gaji', 'slug' => 'edit-proses-gaji', 'module' => 'proses-gaji', 'description' => 'Mengedit proses gaji'],
            ['name' => 'Delete Proses Gaji', 'slug' => 'delete-proses-gaji', 'module' => 'proses-gaji', 'description' => 'Menghapus proses gaji'],

            // Laporan Permissions
            ['name' => 'View Laporan', 'slug' => 'view-laporan', 'module' => 'laporan', 'description' => 'Melihat laporan'],
            ['name' => 'Print Laporan', 'slug' => 'print-laporan', 'module' => 'laporan', 'description' => 'Mencetak laporan'],
            ['name' => 'Export Laporan', 'slug' => 'export-laporan', 'module' => 'laporan', 'description' => 'Export laporan'],

            // Settings Permissions
            ['name' => 'View Settings', 'slug' => 'view-settings', 'module' => 'settings', 'description' => 'Melihat menu settings'],
            ['name' => 'Manage Users', 'slug' => 'manage-users', 'module' => 'settings', 'description' => 'Mengelola user'],
            ['name' => 'Manage Roles', 'slug' => 'manage-roles', 'module' => 'settings', 'description' => 'Mengelola role'],
            ['name' => 'Manage Permissions', 'slug' => 'manage-permissions', 'module' => 'settings', 'description' => 'Mengelola permission'],
        ];

        foreach ($permissions as $perm) {
            Permission::firstOrCreate(
                ['slug' => $perm['slug']],
                $perm
            );
        }

        // Create Roles
        $adminRole = Role::firstOrCreate(
            ['slug' => 'admin'],
            [
                'name' => 'Administrator',
                'description' => 'Akses penuh ke semua fitur aplikasi',
                'is_active' => true,
            ]
        );

        $hrRole = Role::firstOrCreate(
            ['slug' => 'hr'],
            [
                'name' => 'HR',
                'description' => 'Akses untuk Human Resources',
                'is_active' => true,
            ]
        );

        $managerRole = Role::firstOrCreate(
            ['slug' => 'manager'],
            [
                'name' => 'Manager',
                'description' => 'Akses untuk Manager',
                'is_active' => true,
            ]
        );

        $userRole = Role::firstOrCreate(
            ['slug' => 'user'],
            [
                'name' => 'User',
                'description' => 'Akses terbatas untuk user biasa',
                'is_active' => true,
            ]
        );

        // Assign Permissions to Admin Role (All permissions)
        $adminRole->permissions()->sync(Permission::pluck('id')->toArray());

        // Assign Permissions to HR Role
        $hrPermissions = Permission::whereIn('slug', [
            'view-master-data',
            'create-master-data',
            'edit-master-data',
            'delete-master-data',
            'view-absensi',
            'create-absensi',
            'edit-absensi',
            'delete-absensi',
            'view-proses-gaji',
            'create-proses-gaji',
            'edit-proses-gaji',
            'view-laporan',
            'print-laporan',
            'export-laporan',
        ])->pluck('id')->toArray();
        $hrRole->permissions()->sync($hrPermissions);

        // Assign Permissions to Manager Role
        $managerPermissions = Permission::whereIn('slug', [
            'view-absensi',
            'view-proses-gaji',
            'create-proses-gaji',
            'edit-proses-gaji',
            'view-laporan',
            'print-laporan',
            'export-laporan',
        ])->pluck('id')->toArray();
        $managerRole->permissions()->sync($managerPermissions);

        // Assign Permissions to User Role
        $userPermissions = Permission::whereIn('slug', [
            'view-absensi',
            'view-laporan',
            'print-laporan',
        ])->pluck('id')->toArray();
        $userRole->permissions()->sync($userPermissions);

        $this->command->info('Role dan Permission berhasil dibuat!');
        $this->command->info('Roles: Admin, HR, Manager, User');
        $this->command->info('Permissions: ' . Permission::count() . ' permissions telah dibuat');
    }
}
