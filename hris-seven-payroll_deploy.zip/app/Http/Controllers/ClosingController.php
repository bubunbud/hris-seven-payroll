<?php

namespace App\Http\Controllers;

use App\Models\Closing;
use App\Models\PeriodeGaji;
use App\Models\Divisi;
use App\Models\Karyawan;
use App\Models\Gapok;
use App\Models\Absen;
use App\Models\TidakMasuk;
use App\Models\Izin;
use App\Models\HariLibur;
use App\Models\HutangPiutang;
use App\Models\LemburHeader;
use App\Models\LemburDetail;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class ClosingController extends Controller
{
    /**
     * Display the closing gaji form
     */
    public function index()
    {
        // Ambil semua periode yang belum diproses (vcStatus = '0')
        $periodes = PeriodeGaji::with('divisi')
            ->where('vcStatus', '0') // Hanya yang belum diproses
            ->orderBy('periode', 'desc')
            ->orderBy('vcQuarter', 'asc')
            ->orderBy('vcKodeDivisi', 'asc')
            ->get();

        // Ambil periode sebelumnya untuk setiap periode yang ada
        $periodesWithPrevious = [];
        foreach ($periodes as $periode) {
            // Cari periode sebelumnya (periode yang sama tapi closing berbeda, atau periode sebelumnya)
            $periodeSebelumnya = PeriodeGaji::where('vcKodeDivisi', $periode->vcKodeDivisi)
                ->where(function ($q) use ($periode) {
                    // Jika periode closing 2, cari periode closing 1 dengan periode yang sama
                    if ($periode->vcQuarter == '2') {
                        $q->where('periode', $periode->periode)
                            ->where('vcQuarter', '1');
                    } else {
                        // Jika periode closing 1, cari periode closing 2 dari periode sebelumnya
                        $q->where('periode', '<', $periode->periode)
                            ->where('vcQuarter', '2')
                            ->orderBy('periode', 'desc');
                    }
                })
                ->first();

            $periodesWithPrevious[] = [
                'periode' => $periode,
                'periode_sebelumnya' => $periodeSebelumnya,
            ];
        }

        return view('proses.closing.index', compact('periodesWithPrevious'));
    }

    /**
     * Process payroll calculation (store)
     * Method ini akan melakukan perhitungan gaji untuk divisi yang dipilih
     */
    public function store(Request $request)
    {
        $request->validate([
            'periodes' => 'required|array|min:1',
            'periodes.*' => 'required|string', // Format: "dtPeriodeFrom|dtPeriodeTo|periode|vcQuarter|vcKodeDivisi"
        ]);

        DB::beginTransaction();
        try {
            $processed = 0;
            $errors = [];

            foreach ($request->periodes as $periodeKey) {
                $parts = explode('|', $periodeKey);
                if (count($parts) != 5) {
                    $errors[] = "Format periode tidak valid: {$periodeKey}";
                    continue;
                }

                [$dtPeriodeFrom, $dtPeriodeTo, $periode, $vcQuarter, $vcKodeDivisi] = $parts;

                // Ambil data periode
                $periodeGaji = PeriodeGaji::where('dtPeriodeFrom', $dtPeriodeFrom)
                    ->where('dtPeriodeTo', $dtPeriodeTo)
                    ->where('periode', $periode)
                    ->where('vcQuarter', $vcQuarter)
                    ->where('vcKodeDivisi', $vcKodeDivisi)
                    ->first();

                if (!$periodeGaji) {
                    $errors[] = "Periode tidak ditemukan: {$periodeKey}";
                    continue;
                }

                // Proses perhitungan gaji untuk periode ini
                $result = $this->calculatePayroll($dtPeriodeFrom, $dtPeriodeTo, $periode, $vcQuarter, $vcKodeDivisi);

                if ($result['success']) {
                    $processed++;
                    // Update status periode menjadi diproses
                    DB::table('t_periode')
                        ->where('dtPeriodeFrom', $dtPeriodeFrom)
                        ->where('dtPeriodeTo', $dtPeriodeTo)
                        ->where('periode', $periode)
                        ->where('vcQuarter', $vcQuarter)
                        ->where('vcKodeDivisi', $vcKodeDivisi)
                        ->update(['vcStatus' => '1']);
                } else {
                    $errors[] = $result['message'] ?? "Gagal memproses periode: {$periodeKey}";
                }
            }

            DB::commit();

            $message = "Proses gaji selesai. Berhasil: {$processed} periode";
            if (!empty($errors)) {
                $message .= ". Error: " . count($errors) . " periode";
            }

            return response()->json([
                'success' => true,
                'message' => $message,
                'processed' => $processed,
                'errors' => $errors
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            \Log::error('Error processing payroll: ' . $e->getMessage(), [
                'trace' => $e->getTraceAsString()
            ]);
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Calculate payroll for a specific period
     * Method utama untuk perhitungan gaji lengkap
     */
    private function calculatePayroll($dtPeriodeFrom, $dtPeriodeTo, $periode, $vcQuarter, $vcKodeDivisi)
    {
        try {
            $tanggalAwal = Carbon::parse($dtPeriodeFrom);
            $tanggalAkhir = Carbon::parse($dtPeriodeTo);
            $tanggalPeriode = Carbon::parse($periode);

            // 1. Ambil semua karyawan operator aktif dengan divisi yang sesuai
            $karyawans = Karyawan::where('vcAktif', '1')
                ->where('Group_pegawai', 'operator')
                ->where('Divisi', $vcKodeDivisi)
                ->get();

            if ($karyawans->isEmpty()) {
                return [
                    'success' => false,
                    'message' => 'Tidak ada karyawan operator untuk divisi ' . $vcKodeDivisi
                ];
            }

            // 2. Hitung hari kerja (exclude Sabtu, Minggu, hari libur)
            $hariLiburList = $this->getHariLiburList($tanggalAwal, $tanggalAkhir);
            $jumlahHariKerja = $this->calculateWorkingDays($tanggalAwal, $tanggalAkhir, $hariLiburList);

            // 3. Ambil periode sebelumnya untuk perhitungan premi hadir (periode 2)
            $periodeSebelumnya = null;
            $periodeSebelumnyaAwal = null;
            $periodeSebelumnyaAkhir = null;
            if ($vcQuarter == '2') {
                // Cari periode 1 dengan periode yang sama
                $periodeSebelumnya = PeriodeGaji::where('vcKodeDivisi', $vcKodeDivisi)
                    ->where('periode', $periode)
                    ->where('vcQuarter', '1')
                    ->first();
                if ($periodeSebelumnya) {
                    $periodeSebelumnyaAwal = $periodeSebelumnya->dtPeriodeFrom;
                    $periodeSebelumnyaAkhir = $periodeSebelumnya->dtPeriodeTo;
                }
            }

            $processedCount = 0;
            $errors = [];

            // 4. Proses perhitungan untuk setiap karyawan
            foreach ($karyawans as $karyawan) {
                try {
                    $this->calculateEmployeePayroll(
                        $karyawan,
                        $tanggalAwal,
                        $tanggalAkhir,
                        $tanggalPeriode,
                        $vcQuarter,
                        $vcKodeDivisi,
                        $jumlahHariKerja,
                        $hariLiburList,
                        $periodeSebelumnyaAwal,
                        $periodeSebelumnyaAkhir
                    );
                    $processedCount++;
                } catch (\Exception $e) {
                    $errors[] = "NIK {$karyawan->Nik}: " . $e->getMessage();
                    \Log::error("Error calculating payroll for NIK {$karyawan->Nik}: " . $e->getMessage());
                }
            }

            return [
                'success' => true,
                'message' => "Perhitungan gaji berhasil untuk {$processedCount} karyawan" . (!empty($errors) ? ". Error: " . count($errors) : ""),
                'processed' => $processedCount,
                'errors' => $errors
            ];
        } catch (\Exception $e) {
            \Log::error('Error calculating payroll: ' . $e->getMessage(), [
                'trace' => $e->getTraceAsString()
            ]);
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }

    /**
     * Calculate payroll for a single employee
     */
    private function calculateEmployeePayroll($karyawan, $tanggalAwal, $tanggalAkhir, $tanggalPeriode, $vcQuarter, $vcKodeDivisi, $jumlahHariKerja, $hariLiburList, $periodeSebelumnyaAwal = null, $periodeSebelumnyaAkhir = null)
    {
        $nik = (string) $karyawan->Nik;

        // 1. Ambil gaji pokok dari m_gapok
        $gapok = Gapok::find($karyawan->Gol);
        if (!$gapok) {
            throw new \Exception("Golongan {$karyawan->Gol} tidak ditemukan di m_gapok");
        }

        // Gaji Pokok per bulan = Upah + Tunjangan Keluarga + Tunjangan Masa Kerja + Tunjangan Jabatan 1 + Tunjangan Jabatan 2
        $gapokPerBulan = (float) ($gapok->upah ?? 0)
            + (float) ($gapok->tunj_keluarga ?? 0)
            + (float) ($gapok->tunj_masa_kerja ?? 0)
            + (float) ($gapok->tunj_jabatan1 ?? 0)
            + (float) ($gapok->tunj_jabatan2 ?? 0);

        // Gaji Pokok setengah bulan
        $decGapok = $gapokPerBulan / 2;

        $decVarMakan = (float) ($gapok->uang_makan ?? 0);
        $decVarTransport = (float) ($gapok->uang_transport ?? 0);

        // 2. Hitung kehadiran dari t_absen
        $absensi = Absen::where('vcNik', $nik)
            ->whereBetween('dtTanggal', [$tanggalAwal->format('Y-m-d'), $tanggalAkhir->format('Y-m-d')])
            ->get();

        $intHadir = $absensi->where(function ($ab) {
            return !empty($ab->dtJamMasuk) || !empty($ab->dtJamKeluar);
        })->count();

        // 3. Hitung tidak masuk (Ijin Pribadi I002)
        // Gunakan fungsi helper untuk menghitung hari yang benar-benar overlap dengan periode
        $intJmlIzin = $this->calculateHariTidakMasuk($nik, 'I002', $tanggalAwal, $tanggalAkhir);
        $intTidakMasuk = $intJmlIzin; // Untuk field intTidakMasuk
        $decPotonganTidakMasuk = $intJmlIzin * ($gapokPerBulan / 21);

        // 4. Hitung absensi detail (Sakit, Alpha, Cuti, Izin Resmi, Telat)
        // Hanya menghitung hari yang benar-benar overlap dengan range periode
        $intJmlSakit = $this->calculateHariTidakMasuk($nik, 'S010', $tanggalAwal, $tanggalAkhir);
        $intJmlCuti = $this->calculateHariTidakMasuk($nik, 'C010', $tanggalAwal, $tanggalAkhir);
        $intJmlIzinR = $this->calculateHariTidakMasuk($nik, 'I001', $tanggalAwal, $tanggalAkhir);

        // 5. Hitung Alpha: Hari kerja yang tidak ada absensi dan tidak ada ijin/tidak masuk
        $intJmlAlpha = $this->calculateAlpha($nik, $tanggalAwal, $tanggalAkhir, $hariLiburList, $karyawan);

        // 6. Hitung telat: Jam masuk > jam shift masuk (lebih dari 1 menit)
        $intJmlTelat = $this->calculateTelat($absensi, $karyawan);

        // 7. Hitung ijin keluar komplek (Z003, Z004) - untuk keperluan pribadi
        $izinKeluar = Izin::where('vcNik', $nik)
            ->whereIn('vcKodeIzin', ['Z003', 'Z004'])
            ->whereBetween('dtTanggal', [$tanggalAwal->format('Y-m-d'), $tanggalAkhir->format('Y-m-d')])
            ->get();

        $intHC = $izinKeluar->count();
        $totalJamIzinKeluar = $this->calculateTotalJamIzinKeluar($izinKeluar, $karyawan);
        $decPotonganHC = $totalJamIzinKeluar * ($gapokPerBulan / (21 * 8));

        // 7. Hitung lembur
        $lemburData = $this->calculateLembur($absensi, $hariLiburList, $gapokPerBulan);

        // 8. Hitung tunjangan makan dan transport
        $tunjanganData = $this->calculateTunjanganMakanTransport($absensi, $hariLiburList, $decVarMakan, $decVarTransport, $lemburData);

        // 9. Hitung potongan BPJS (hanya periode 1)
        $decPotonganBPJSKes = 0;
        $decPotonganBPJSJHT = 0;
        $decPotonganBPJSJP = 0;
        if ($vcQuarter == '1') {
            $decPotonganBPJSKes = $gapokPerBulan * 0.01; // 1%
            $decPotonganBPJSJHT = $gapokPerBulan * 0.02; // 2%
            $decPotonganBPJSJP = $gapokPerBulan * 0.01; // 1%
        }

        // 10. Hitung potongan dari hutang piutang
        $potonganHutangPiutang = $this->calculatePotonganHutangPiutang($nik, $tanggalAwal, $tanggalAkhir, $vcQuarter);

        // 11. Hitung premi hadir dan copy data absensi P1 ke field int*Lalu (hanya periode 2)
        $decPremi = 0;
        $intCutiLalu = 0;
        $intSakitLalu = 0;
        $intHcLalu = 0;
        $intIzinLalu = 0;
        $intAlphaLalu = 0;
        $intTelatLalu = 0;

        if ($vcQuarter == '2') {
            // Ambil data closing periode 1 (P1) dari periode gajian yang sama (tanggal 1 atau 15 di bulan yang sama)
            // Jika periode gajian adalah tanggal 15, maka cari closing P1 dengan periode tanggal 1 di bulan yang sama
            // Jika periode gajian adalah tanggal 1, maka cari closing P1 dengan periode tanggal 15 di bulan sebelumnya
            $periodeP1 = null;
            if ($tanggalPeriode->day == 15) {
                // Periode gajian 15, cari closing P1 dengan periode tanggal 1 di bulan yang sama
                $periodeP1 = $tanggalPeriode->copy()->day(1)->format('Y-m-d');
            } else {
                // Periode gajian 1, cari closing P1 dengan periode tanggal 15 di bulan sebelumnya
                $periodeP1 = $tanggalPeriode->copy()->subMonth()->day(15)->format('Y-m-d');
            }

            $closingP1 = Closing::where('vcNik', $nik)
                ->where('periode', $periodeP1)
                ->where('vcClosingKe', '1')
                ->where('vcKodeDivisi', $vcKodeDivisi)
                ->first();

            if ($closingP1) {
                // Copy data absensi P1 ke field int*Lalu
                $intCutiLalu = $closingP1->intJmlCuti ?? 0;
                $intSakitLalu = $closingP1->intJmlSakit ?? 0;
                $intHcLalu = $closingP1->intHC ?? 0;
                $intIzinLalu = $closingP1->intJmlIzin ?? 0;
                $intAlphaLalu = $closingP1->intJmlAlpha ?? 0;
                $intTelatLalu = $closingP1->intJmlTelat ?? 0;

                // Hitung premi hadir berdasarkan aturan: I + A + T + HC (P1 + P2)
                // I = Izin Pribadi (I002)
                // A = Alpha
                // T = Telat
                // HC = Ijin keluar komplek untuk keperluan pribadi (Z003, Z004)
                $totalIATHC = $intIzinLalu + $intJmlIzin +  // Izin Pribadi (P1 + P2)
                    $intAlphaLalu + $intJmlAlpha + // Alpha (P1 + P2)
                    $intTelatLalu + $intJmlTelat + // Telat (P1 + P2)
                    $intHcLalu + $intHC;           // HC (P1 + P2)

                // Ambil tarif premi dari m_gapok
                $tarifPremi = (float) ($gapok->premi ?? 0);

                if ($totalIATHC == 0) {
                    $decPremi = $tarifPremi; // Full premi
                } elseif ($totalIATHC == 1) {
                    $decPremi = $tarifPremi / 2; // Setengah premi
                } else {
                    $decPremi = 0; // Tidak dapat premi
                }
            }
        }

        // 12. Hitung kerja hari libur (KHL)
        $intKHL = $absensi->filter(function ($ab) use ($hariLiburList) {
            $tanggalStr = $ab->dtTanggal instanceof Carbon
                ? $ab->dtTanggal->format('Y-m-d')
                : Carbon::parse($ab->dtTanggal)->format('Y-m-d');
            return in_array($tanggalStr, $hariLiburList) && !empty($ab->dtJamMasukLembur);
        })->count();

        // 13. Hitung total jam kerja
        $decJamKerja = $absensi->sum(function ($ab) {
            return $ab->total_jam ?? 0;
        });

        // 14. Simpan ke t_closing
        $closingData = [
            'vcPeriodeAwal' => $tanggalAwal->format('Y-m-d'),
            'vcPeriodeAkhir' => $tanggalAkhir->format('Y-m-d'),
            'vcNik' => $nik,
            'periode' => $tanggalPeriode->format('Y-m-d'),
            'vcClosingKe' => $vcQuarter,
            'jumlahHari' => $jumlahHariKerja,
            'vcKodeGolongan' => $karyawan->Gol,
            'vcKodeDivisi' => $vcKodeDivisi,
            'vcStatusPegawai' => $karyawan->Status_Pegawai,
            'decGapok' => $decGapok,
            'decJamKerja' => $decJamKerja,
            'decPotonganHC' => $decPotonganHC,
            'decPotonganBPR' => $potonganHutangPiutang['dplk'],
            'decIuranSPN' => $potonganHutangPiutang['spn'],
            'decPotonganBPJSKes' => $decPotonganBPJSKes,
            'decPotonganBPJSJHT' => $decPotonganBPJSJHT,
            'decPotonganBPJSJP' => $decPotonganBPJSJP,
            'decPotonganKoperasi' => $potonganHutangPiutang['koperasi'],
            'decPotonganAbsen' => $decPotonganTidakMasuk, // Potongan ijin pribadi (tidak masuk)
            'decPotonganLain' => $potonganHutangPiutang['lain'], // Potongan lain-lain dari hutang piutang
            'decVarMakan' => $decVarMakan,
            'decVarTransport' => $decVarTransport,
            'decRapel' => $this->getRapel($nik, $tanggalAwal, $tanggalAkhir),
            'decUangMakan' => $tunjanganData['total_makan'],
            'decTransport' => $tunjanganData['total_transport'],
            'intMakan' => $tunjanganData['jumlah_makan'],
            'intTransport' => $tunjanganData['jumlah_transport'],
            'intHC' => $intHC,
            'intKHL' => $intKHL,
            'intHadir' => $intHadir,
            'intTidakMasuk' => $intTidakMasuk,
            'intJumlahHari' => $jumlahHariKerja,
            'intJmlSakit' => $intJmlSakit,
            'intJmlAlpha' => $intJmlAlpha,
            'intJmlIzin' => $intJmlIzin,
            'intJmlIzinR' => $intJmlIzinR,
            'intJmlCuti' => $intJmlCuti,
            'intJmlTelat' => $intJmlTelat,
            'decPremi' => $decPremi,
            'decJamLemburKerja1' => $lemburData['jam_kerja_1'],
            'decJamLemburKerja2' => $lemburData['jam_kerja_2'],
            'decJamLemburKerja3' => $lemburData['jam_kerja_3'],
            'decLemburKerja1' => $lemburData['rupiah_kerja_1'],
            'decLemburKerja2' => $lemburData['rupiah_kerja_2'],
            'decLemburKerja3' => $lemburData['rupiah_kerja_3'],
            'decJamLemburLibur2' => $lemburData['jam_libur_2'],
            'decJamLemburLibur3' => $lemburData['jam_libur_3'],
            'decLembur2' => $lemburData['rupiah_libur_2'],
            'decLembur3' => $lemburData['rupiah_libur_3'],
            'decJamLemburKerja' => $lemburData['total_jam_kerja'],
            'decJamLemburLibur' => $lemburData['total_jam_libur'],
            'decTotallembur1' => $lemburData['rupiah_kerja_1'],
            'decTotallembur2' => $lemburData['rupiah_kerja_2'] + $lemburData['rupiah_libur_2'],
            'decTotallembur3' => $lemburData['rupiah_kerja_3'] + $lemburData['rupiah_libur_3'],
            'intCutiLalu' => $intCutiLalu,
            'intSakitLalu' => $intSakitLalu,
            'intHcLalu' => $intHcLalu,
            'intIzinLalu' => $intIzinLalu,
            'intAlphaLalu' => $intAlphaLalu,
            'intTelatLalu' => $intTelatLalu,
            'intMakanKerja' => $tunjanganData['makan_kerja'],
            'intMakanLibur' => $tunjanganData['makan_libur'],
            'intTransportKerja' => $tunjanganData['transport_kerja'],
            'intTransportLibur' => $tunjanganData['transport_libur'],
            'decBpjsKesehatan' => $decPotonganBPJSKes,
            'decBpjsNaker' => $decPotonganBPJSJHT,
            'decBpjsPensiun' => $decPotonganBPJSJP,
            'decBebanTgi' => $lemburData['beban_tgi'],
            'decBebanSiaExp' => $lemburData['beban_sia_exp'],
            'decBebanSiaProd' => $lemburData['beban_sia_prod'],
            'decBebanRma' => $lemburData['beban_rma'],
            'decBebanSmu' => $lemburData['beban_smu'],
            'decBebanAbnJkt' => $lemburData['beban_abn_jkt'],
            'dtCreate' => Carbon::now(),
            'dtChange' => Carbon::now(),
        ];

        // Update or insert ke t_closing
        DB::table('t_closing')->updateOrInsert(
            [
                'vcPeriodeAwal' => $closingData['vcPeriodeAwal'],
                'vcPeriodeAkhir' => $closingData['vcPeriodeAkhir'],
                'vcNik' => $closingData['vcNik'],
                'periode' => $closingData['periode'],
                'vcClosingKe' => $closingData['vcClosingKe'],
            ],
            $closingData
        );
    }

    /**
     * Get list of holidays (including weekends)
     */
    private function getHariLiburList($tanggalAwal, $tanggalAkhir)
    {
        $hariLibur = HariLibur::whereBetween('dtTanggal', [$tanggalAwal->format('Y-m-d'), $tanggalAkhir->format('Y-m-d')])
            ->pluck('dtTanggal')
            ->map(function ($tanggal) {
                return $tanggal instanceof Carbon ? $tanggal->format('Y-m-d') : Carbon::parse($tanggal)->format('Y-m-d');
            })
            ->toArray();

        // Tambahkan Sabtu dan Minggu
        $current = $tanggalAwal->copy();
        while ($current->lte($tanggalAkhir)) {
            if (in_array($current->dayOfWeek, [0, 6])) { // 0 = Minggu, 6 = Sabtu
                $tanggalStr = $current->format('Y-m-d');
                if (!in_array($tanggalStr, $hariLibur)) {
                    $hariLibur[] = $tanggalStr;
                }
            }
            $current->addDay();
        }

        return $hariLibur;
    }

    /**
     * Calculate working days (exclude weekends and holidays)
     */
    private function calculateWorkingDays($tanggalAwal, $tanggalAkhir, $hariLiburList)
    {
        $count = 0;
        $current = $tanggalAwal->copy();
        while ($current->lte($tanggalAkhir)) {
            $tanggalStr = $current->format('Y-m-d');
            if (!in_array($tanggalStr, $hariLiburList)) {
                $count++;
            }
            $current->addDay();
        }
        return $count;
    }

    /**
     * Calculate total hours for izin keluar komplek
     */
    private function calculateTotalJamIzinKeluar($izinKeluar, $karyawan)
    {
        $totalJam = 0;
        foreach ($izinKeluar as $izin) {
            if (!$izin->dtDari) continue;

            $tanggal = $izin->dtTanggal instanceof Carbon ? $izin->dtTanggal->copy() : Carbon::parse($izin->dtTanggal);
            $dari = $tanggal->copy()->setTimeFromTimeString((string) $izin->dtDari);

            // Tentukan sampai
            $rawSampai = $izin->dtSampai ? (string) $izin->dtSampai : null;
            $isZero = $rawSampai && (substr($rawSampai, 0, 5) === '00:00');
            $shiftPulang = null;
            if ($karyawan->shift && $karyawan->shift->vcPulang) {
                $shiftPulang = $karyawan->shift->vcPulang instanceof Carbon
                    ? $karyawan->shift->vcPulang->format('H:i')
                    : substr((string) $karyawan->shift->vcPulang, 0, 5);
            }
            $sampaiClock = (!$rawSampai || $isZero) ? $shiftPulang : substr($rawSampai, 0, 5);
            if (!$sampaiClock) continue;

            $sampai = $tanggal->copy()->setTimeFromTimeString($sampaiClock);
            if ($sampai->lessThan($dari)) {
                $sampai->addDay();
            }

            $menit = $dari->diffInMinutes($sampai, true);
            // Kurangi 1 jam jika melewati jam istirahat 12:00-13:00
            $lunchStart = $tanggal->copy()->setTimeFromTimeString('12:00');
            $lunchEnd = $tanggal->copy()->setTimeFromTimeString('13:00');
            if ($dari->lt($lunchEnd) && $sampai->gt($lunchStart)) {
                $menit = max(0, $menit - 60);
            }

            $totalJam += round($menit / 60, 2);
        }
        return $totalJam;
    }

    /**
     * Calculate lembur (overtime) for employee
     */
    private function calculateLembur($absensi, $hariLiburList, $gapokPerBulan)
    {
        $jamKerja1 = 0;
        $rupiahKerja1 = 0;
        $jamKerja2 = 0;
        $rupiahKerja2 = 0;
        $jamKerja3 = 0;
        $rupiahKerja3 = 0;
        $jamLibur2 = 0;
        $rupiahLibur2 = 0;
        $jamLibur3 = 0;
        $rupiahLibur3 = 0;
        $bebanTgi = 0;
        $bebanSiaExp = 0;
        $bebanSiaProd = 0;
        $bebanRma = 0;
        $bebanSmu = 0;
        $bebanAbnJkt = 0;

        $ratePerJam = $gapokPerBulan / 173;

        foreach ($absensi as $absen) {
            if (empty($absen->dtJamMasukLembur) || empty($absen->dtJamKeluarLembur)) continue;
            if (empty($absen->vcCounter)) continue; // Hanya lembur yang sudah dikonfirmasi

            $tanggalStr = $absen->dtTanggal instanceof Carbon
                ? $absen->dtTanggal->format('Y-m-d')
                : Carbon::parse($absen->dtTanggal)->format('Y-m-d');

            $isHariLibur = in_array($tanggalStr, $hariLiburList);

            // Hitung jam lembur dengan presisi lebih baik
            $jamMasukLembur = substr((string) $absen->dtJamMasukLembur, 0, 5);
            $jamKeluarLembur = substr((string) $absen->dtJamKeluarLembur, 0, 5);

            $tanggal = $absen->dtTanggal instanceof Carbon ? $absen->dtTanggal->copy() : Carbon::parse($absen->dtTanggal);
            $masukLembur = $tanggal->copy()->setTimeFromTimeString($jamMasukLembur);
            $keluarLembur = $tanggal->copy()->setTimeFromTimeString($jamKeluarLembur);

            if ($keluarLembur->lessThan($masukLembur)) {
                $keluarLembur->addDay();
            }

            // Hitung total jam lembur dengan presisi (dalam jam, bisa desimal)
            $totalMenitLembur = $masukLembur->diffInMinutes($keluarLembur, true);

            // Kurangi waktu istirahat (dalam menit) jika ada
            $durasiIstirahat = $absen->intDurasiIstirahat ?? 0;
            if ($durasiIstirahat > 0) {
                $totalMenitLembur = max(0, $totalMenitLembur - $durasiIstirahat);
            }

            $totalJamLembur = round($totalMenitLembur / 60, 2); // Bulatkan ke 2 desimal

            if ($isHariLibur) {
                // Hari libur: 2x (8 jam pertama), 3x (jam ke-9), 4x (jam ke-10 sampai 12)
                if ($totalJamLembur > 0) {
                    $jam1 = min(8, $totalJamLembur);
                    $jam2 = $totalJamLembur > 8 ? min(1, $totalJamLembur - 8) : 0;
                    $jam3 = $totalJamLembur > 9 ? min(3, $totalJamLembur - 9) : 0;

                    $rupiah2 = $jam1 * 2 * $ratePerJam;
                    $rupiah3 = $jam2 * 3 * $ratePerJam + $jam3 * 4 * $ratePerJam;

                    $jamLibur2 += $jam1;
                    $jamLibur3 += ($jam2 + $jam3);
                    $rupiahLibur2 += $rupiah2;
                    $rupiahLibur3 += $rupiah3;
                }
            } else {
                // Hari kerja normal (HKN): 1.5x (jam pertama), 2x (jam berikutnya)
                // Perhitungan: Jam ke-1 maksimal 1 jam per hari, sisanya masuk ke Jam ke-2
                // Contoh: 
                // - Total 2 jam → J1=1 jam, J2=1 jam
                // - Total 4 jam → J1=1 jam, J2=3 jam
                // - Total 8 jam → J1=1 jam, J2=7 jam
                if ($totalJamLembur > 0) {
                    // Jam ke-1: maksimal 1 jam per hari (hanya di hari kerja)
                    $jam1 = min(1, $totalJamLembur);
                    // Jam ke-2: sisa jam setelah jam ke-1 (hanya di hari kerja)
                    $jam2 = max(0, $totalJamLembur - $jam1);

                    // Hitung rupiah: Jam ke-1 = 1.5x, Jam ke-2 = 2x
                    $rupiah1 = $jam1 * 1.5 * $ratePerJam;
                    $rupiah2 = $jam2 * 2 * $ratePerJam;

                    // Akumulasi per hari kerja
                    $jamKerja1 += $jam1;
                    $jamKerja2 += $jam2;
                    $rupiahKerja1 += $rupiah1;
                    $rupiahKerja2 += $rupiah2;
                }
            }

            // Hitung beban lembur berdasarkan penanggung beban dari detail
            // Ambil LemburDetail berdasarkan vcCounterHeader dan NIK
            $lemburDetail = LemburDetail::where('vcCounterHeader', $absen->vcCounter)
                ->where('vcNik', $absen->vcNik)
                ->first();

            if ($lemburDetail && $lemburDetail->decLemburExternal && $lemburDetail->vcPenanggungBebanLembur) {
                // Gunakan nominal dari decLemburExternal (sudah dihitung saat input)
                $bebanLembur = (float) $lemburDetail->decLemburExternal;
                $penanggungBeban = trim($lemburDetail->vcPenanggungBebanLembur);

                // Mapping penanggung beban ke field beban
                if ($penanggungBeban === 'TGI') {
                    $bebanTgi += $bebanLembur;
                } elseif ($penanggungBeban === 'SIA-EXP') {
                    $bebanSiaExp += $bebanLembur;
                } elseif ($penanggungBeban === 'SIA-PROD') {
                    $bebanSiaProd += $bebanLembur;
                } elseif ($penanggungBeban === 'RMA') {
                    $bebanRma += $bebanLembur;
                } elseif ($penanggungBeban === 'SMU') {
                    $bebanSmu += $bebanLembur;
                } elseif ($penanggungBeban === 'ABN-JKT') {
                    $bebanAbnJkt += $bebanLembur;
                }
            } else {
                // Fallback: Jika decLemburExternal tidak ada, hitung seperti sebelumnya (backward compatibility)
                $lemburHeader = LemburHeader::find($absen->vcCounter);
                if ($lemburHeader) {
                    $penanggungBiaya = $lemburHeader->vcPenanggungBiaya ?? '';
                    $bebanLembur = 0;

                    if ($isHariLibur) {
                        $bebanLembur = $rupiahLibur2 + $rupiahLibur3;
                    } else {
                        $bebanLembur = $rupiahKerja1 + $rupiahKerja2;
                    }

                    // Mapping penanggung biaya ke field beban (backward compatibility)
                    if (stripos($penanggungBiaya, 'TGI') !== false) {
                        $bebanTgi += $bebanLembur;
                    } elseif (stripos($penanggungBiaya, 'SIA Export') !== false || stripos($penanggungBiaya, 'SIA-EXP') !== false) {
                        $bebanSiaExp += $bebanLembur;
                    } elseif (stripos($penanggungBiaya, 'SIA Produksi') !== false || stripos($penanggungBiaya, 'SIA-PROD') !== false || stripos($penanggungBiaya, 'SIA-P11') !== false || stripos($penanggungBiaya, 'SIA-P12') !== false) {
                        $bebanSiaProd += $bebanLembur;
                    } elseif (stripos($penanggungBiaya, 'RMA') !== false) {
                        $bebanRma += $bebanLembur;
                    } elseif (stripos($penanggungBiaya, 'Sutek') !== false || stripos($penanggungBiaya, 'SMU') !== false) {
                        $bebanSmu += $bebanLembur;
                    } elseif (stripos($penanggungBiaya, 'Abadinusa') !== false || stripos($penanggungBiaya, 'ABN-JKT') !== false) {
                        $bebanAbnJkt += $bebanLembur;
                    }
                }
            }
        }

        return [
            'jam_kerja_1' => $jamKerja1,
            'jam_kerja_2' => $jamKerja2,
            'jam_kerja_3' => $jamKerja3,
            'rupiah_kerja_1' => $rupiahKerja1,
            'rupiah_kerja_2' => $rupiahKerja2,
            'rupiah_kerja_3' => $rupiahKerja3,
            'jam_libur_2' => $jamLibur2,
            'jam_libur_3' => $jamLibur3,
            'rupiah_libur_2' => $rupiahLibur2,
            'rupiah_libur_3' => $rupiahLibur3,
            'total_jam_kerja' => $jamKerja1 + $jamKerja2 + $jamKerja3,
            'total_jam_libur' => $jamLibur2 + $jamLibur3,
            'beban_tgi' => $bebanTgi,
            'beban_sia_exp' => $bebanSiaExp,
            'beban_sia_prod' => $bebanSiaProd,
            'beban_rma' => $bebanRma,
            'beban_smu' => $bebanSmu,
            'beban_abn_jkt' => $bebanAbnJkt,
        ];
    }

    /**
     * Calculate tunjangan makan dan transport
     */
    private function calculateTunjanganMakanTransport($absensi, $hariLiburList, $decVarMakan, $decVarTransport, $lemburData)
    {
        $makanKerja = 0;
        $makanLibur = 0;
        $transportKerja = 0;
        $transportLibur = 0;

        foreach ($absensi as $absen) {
            $tanggalStr = $absen->dtTanggal instanceof Carbon
                ? $absen->dtTanggal->format('Y-m-d')
                : Carbon::parse($absen->dtTanggal)->format('Y-m-d');

            $isHariLibur = in_array($tanggalStr, $hariLiburList);

            // Jika ada jam masuk/keluar, berarti hadir (untuk hari kerja)
            if (!empty($absen->dtJamMasuk) || !empty($absen->dtJamKeluar)) {
                if (!$isHariLibur) {
                    // Hari kerja: dapat makan dan transport dari kehadiran
                    $makanKerja++;
                    $transportKerja++;
                }
            }

            // Hitung tunjangan makan dan transport lembur berdasarkan Realisasi Lembur
            // Hanya yang memiliki vcCounter (dari Instruksi Kerja Lembur)
            if (!empty($absen->dtJamMasukLembur) && !empty($absen->dtJamKeluarLembur) && !empty($absen->vcCounter)) {
                $jamMasukLembur = substr((string) $absen->dtJamMasukLembur, 0, 5);
                $jamKeluarLembur = substr((string) $absen->dtJamKeluarLembur, 0, 5);

                $tanggal = $absen->dtTanggal instanceof Carbon ? $absen->dtTanggal->copy() : Carbon::parse($absen->dtTanggal);
                $masukLembur = $tanggal->copy()->setTimeFromTimeString($jamMasukLembur);
                $keluarLembur = $tanggal->copy()->setTimeFromTimeString($jamKeluarLembur);

                if ($keluarLembur->lessThan($masukLembur)) {
                    $keluarLembur->addDay();
                }

                // Hitung total menit lembur
                $totalMenitLembur = $masukLembur->diffInMinutes($keluarLembur, true);

                // Kurangi waktu istirahat (dalam menit) jika ada
                $durasiIstirahat = $absen->intDurasiIstirahat ?? 0;
                if ($durasiIstirahat > 0) {
                    $totalMenitLembur = max(0, $totalMenitLembur - $durasiIstirahat);
                }

                // Konversi ke jam
                $jamLembur = round($totalMenitLembur / 60, 2);

                if ($isHariLibur) {
                    // Hari Libur: 
                    // - Jika >= 4 jam: dapat 1x makan + 1x transport
                    // - Jika < 4 jam: tidak dapat makan, tapi tetap dapat 1x transport
                    if ($jamLembur >= 4) {
                        $makanLibur++;
                    }
                    // Transport tetap diberikan untuk hari libur yang lembur
                    $transportLibur++;
                } else {
                    // Hari Kerja: 
                    // - Jika >= 4 jam: dapat 1x makan tambahan
                    if ($jamLembur >= 4) {
                        $makanKerja++;
                    }
                }
            }
        }

        $totalMakan = ($makanKerja + $makanLibur) * $decVarMakan;
        $totalTransport = ($transportKerja + $transportLibur) * $decVarTransport;

        return [
            'makan_kerja' => $makanKerja,
            'makan_libur' => $makanLibur,
            'transport_kerja' => $transportKerja,
            'transport_libur' => $transportLibur,
            'jumlah_makan' => $makanKerja + $makanLibur,
            'jumlah_transport' => $transportKerja + $transportLibur,
            'total_makan' => $totalMakan,
            'total_transport' => $totalTransport,
        ];
    }

    /**
     * Calculate potongan dari hutang piutang
     */
    private function calculatePotonganHutangPiutang($nik, $tanggalAwal, $tanggalAkhir, $vcQuarter)
    {
        // Ambil hutang piutang yang flag Debit (untuk potongan)
        // vcFlag bisa 'Debit', '1', atau 'Kredit'
        // vcPeriodik bisa '0' atau '1' - untuk potongan periodik biasanya '1'
        $hutangPiutang = HutangPiutang::where('vcNik', $nik)
            ->where(function ($q) {
                // vcFlag bisa 'Debit' atau '1' untuk potongan
                $q->where('vcFlag', 'Debit')
                    ->orWhere('vcFlag', '1');
            })
            ->where(function ($q) use ($tanggalAwal, $tanggalAkhir) {
                // Periode yang overlap dengan periode closing
                $q->where(function ($qq) use ($tanggalAwal, $tanggalAkhir) {
                    $qq->where('dtTanggalAwal', '<=', $tanggalAkhir->format('Y-m-d'))
                        ->where('dtTanggalAkhir', '>=', $tanggalAwal->format('Y-m-d'));
                });
            })
            ->with('masterHutangPiutang')
            ->get();

        $koperasi = 0;
        $spn = 0;
        $dplk = 0;
        $lain = 0;

        foreach ($hutangPiutang as $hp) {
            $vcJenis = trim($hp->vcJenis ?? '');
            $amount = (float) ($hp->decAmount ?? 0);

            // Jika vcPeriodik = '1', maka potongan periodik (diambil setiap periode)
            // Jika vcPeriodik = '0', mungkin potongan satu kali atau perlu dicek lagi
            // Untuk sementara, ambil semua yang flag Debit/1

            // Koperasi: vcJenis = '0' (dari master: 'Potongan Koperasi')
            if ($vcJenis == '0') {
                $koperasi += $amount;
            }
            // SPN: vcJenis = '2' (dari master: 'Potongan SPN'), hanya di periode 2
            elseif ($vcJenis == '2' && $vcQuarter == '2') {
                $spn += $amount;
            }
            // DPLK: vcJenis = '1' (dari master: 'Potongan DPLK')
            elseif ($vcJenis == '1') {
                $dplk += $amount;
            }
            // Lain-lain (potongan lainnya)
            else {
                $lain += $amount;
            }
        }

        return [
            'koperasi' => $koperasi,
            'spn' => $spn,
            'dplk' => $dplk,
            'lain' => $lain,
        ];
    }

    /**
     * Get data periode sebelumnya untuk perhitungan premi hadir
     */
    private function getDataPeriodeSebelumnya($nik, $tanggalAwal, $tanggalAkhir)
    {
        // Gunakan fungsi helper untuk menghitung hari yang benar-benar overlap dengan periode
        $cuti = $this->calculateHariTidakMasuk($nik, 'C010', $tanggalAwal, $tanggalAkhir);
        $sakit = $this->calculateHariTidakMasuk($nik, 'S010', $tanggalAwal, $tanggalAkhir);
        $izin = $this->calculateHariTidakMasuk($nik, 'I002', $tanggalAwal, $tanggalAkhir);

        $hc = Izin::where('vcNik', $nik)
            ->whereIn('vcKodeIzin', ['Z003', 'Z004'])
            ->whereBetween('dtTanggal', [$tanggalAwal->format('Y-m-d'), $tanggalAkhir->format('Y-m-d')])
            ->count();

        // Hitung alpha dan telat dari absensi
        $absensiPeriodeLalu = Absen::where('vcNik', $nik)
            ->whereBetween('dtTanggal', [$tanggalAwal->format('Y-m-d'), $tanggalAkhir->format('Y-m-d')])
            ->get();
        $karyawanObj = Karyawan::find($nik);
        $alpha = $this->calculateAlpha($nik, $tanggalAwal, $tanggalAkhir, $this->getHariLiburList($tanggalAwal, $tanggalAkhir), $karyawanObj);
        $telat = $this->calculateTelat($absensiPeriodeLalu, $karyawanObj);

        return [
            'cuti' => $cuti,
            'sakit' => $sakit,
            'izin' => $izin,
            'hc' => $hc,
            'alpha' => $alpha,
            'telat' => $telat,
        ];
    }

    /**
     * Calculate Alpha (hari kerja yang tidak ada absensi dan tidak ada ijin)
     */
    private function calculateAlpha($nik, $tanggalAwal, $tanggalAkhir, $hariLiburList, $karyawan)
    {
        // Dapatkan semua tanggal hari kerja dalam periode
        $current = $tanggalAwal->copy();
        $alphaCount = 0;

        while ($current->lte($tanggalAkhir)) {
            $tanggalStr = $current->format('Y-m-d');

            // Skip hari libur (termasuk weekend)
            $dayOfWeek = $current->dayOfWeek;
            $isWeekend = ($dayOfWeek == 0 || $dayOfWeek == 6);
            if ($isWeekend || in_array($tanggalStr, $hariLiburList)) {
                $current->addDay();
                continue;
            }

            // Cek apakah ada absensi dengan jam masuk/keluar
            $absen = Absen::where('vcNik', $nik)
                ->where('dtTanggal', $tanggalStr)
                ->first();

            $hasAbsensi = $absen && (!empty($absen->dtJamMasuk) || !empty($absen->dtJamKeluar));

            // Cek apakah ada ijin/tidak masuk pada tanggal ini
            $hasIjin = TidakMasuk::where('vcNik', $nik)
                ->where(function ($q) use ($tanggalStr) {
                    $q->where('dtTanggalMulai', '<=', $tanggalStr)
                        ->where('dtTanggalSelesai', '>=', $tanggalStr);
                })
                ->exists();

            // Jika tidak ada absensi dan tidak ada ijin, maka alpha
            if (!$hasAbsensi && !$hasIjin) {
                $alphaCount++;
            }

            $current->addDay();
        }

        return $alphaCount;
    }

    /**
     * Calculate Telat (jam masuk > jam shift masuk)
     * Telat dihitung jika jam masuk lebih dari jam shift masuk (bahkan 1 menit pun sudah telat)
     */
    private function calculateTelat($absensi, $karyawan)
    {
        if (!$karyawan || !$karyawan->shift || !$karyawan->shift->vcMasuk) {
            return 0;
        }

        $telatCount = 0;

        // Ambil jam shift masuk
        $shiftMasuk = $karyawan->shift->vcMasuk instanceof Carbon
            ? $karyawan->shift->vcMasuk->format('H:i')
            : substr((string) $karyawan->shift->vcMasuk, 0, 5);

        if (!$shiftMasuk) {
            return 0;
        }

        foreach ($absensi as $absen) {
            if (empty($absen->dtJamMasuk)) {
                continue;
            }

            $tanggal = $absen->dtTanggal instanceof Carbon ? $absen->dtTanggal->copy() : Carbon::parse($absen->dtTanggal);
            $jamMasuk = substr((string) $absen->dtJamMasuk, 0, 5);

            try {
                $tMasuk = $tanggal->copy()->setTimeFromTimeString($jamMasuk);
                $tShiftMasuk = $tanggal->copy()->setTimeFromTimeString($shiftMasuk);

                // Jika jam masuk lebih dari jam shift masuk (bahkan 1 menit pun sudah telat), dihitung telat
                if ($tMasuk->greaterThan($tShiftMasuk)) {
                    $telatCount++;
                }
            } catch (\Exception $e) {
                // Skip jika ada error parsing waktu
                continue;
            }
        }

        return $telatCount;
    }

    /**
     * Calculate hari tidak masuk yang benar-benar overlap dengan range periode
     * Hanya menghitung hari yang masuk dalam range periode, bukan seluruh jumlah_hari
     * 
     * Overlap terjadi jika:
     * - dtTanggalMulai <= tanggalAkhir AND dtTanggalSelesai >= tanggalAwal
     */
    private function calculateHariTidakMasuk($nik, $kodeAbsen, $tanggalAwal, $tanggalAkhir)
    {
        // Query untuk mencari semua record tidak masuk yang overlap dengan periode
        // Overlap terjadi jika: dtTanggalMulai <= tanggalAkhir AND dtTanggalSelesai >= tanggalAwal
        $tidakMasukRecords = TidakMasuk::where('vcNik', $nik)
            ->where('vcKodeAbsen', $kodeAbsen)
            ->where('dtTanggalMulai', '<=', $tanggalAkhir->format('Y-m-d'))
            ->where('dtTanggalSelesai', '>=', $tanggalAwal->format('Y-m-d'))
            ->get();

        $totalHari = 0;

        foreach ($tidakMasukRecords as $record) {
            if (!$record->dtTanggalMulai || !$record->dtTanggalSelesai) {
                continue;
            }

            $mulai = Carbon::parse($record->dtTanggalMulai);
            $selesai = Carbon::parse($record->dtTanggalSelesai);

            // Tentukan range overlap: mulai dari max(tanggal mulai, tanggal awal periode) sampai min(tanggal selesai, tanggal akhir periode)
            $overlapMulai = $mulai->greaterThan($tanggalAwal) ? $mulai->copy() : $tanggalAwal->copy();
            $overlapSelesai = $selesai->lessThan($tanggalAkhir) ? $selesai->copy() : $tanggalAkhir->copy();

            // Hitung hari overlap (inklusif)
            if ($overlapMulai->lte($overlapSelesai)) {
                $hariOverlap = $overlapMulai->diffInDays($overlapSelesai) + 1;
                $totalHari += $hariOverlap;
            }
        }

        return $totalHari;
    }

    /**
     * Get Rapel (selisih upah) from t_hutang_piutang or default to 0
     */
    private function getRapel($nik, $tanggalAwal, $tanggalAkhir)
    {
        // Cari rapel dari t_hutang_piutang dengan jenis 'RAPEL' atau flag Credit (penerimaan)
        $rapel = HutangPiutang::where('vcNik', $nik)
            ->where(function ($q) {
                $q->where('vcJenis', 'RAPEL')
                    ->orWhere(function ($qq) {
                        $qq->where('vcFlag', 'Credit') // Penerimaan
                            ->where('vcJenis', 'LIKE', '%RAPEL%');
                    });
            })
            ->where(function ($q) use ($tanggalAwal, $tanggalAkhir) {
                $q->where(function ($qq) use ($tanggalAwal, $tanggalAkhir) {
                    $qq->where('dtTanggalAwal', '<=', $tanggalAkhir->format('Y-m-d'))
                        ->where('dtTanggalAkhir', '>=', $tanggalAwal->format('Y-m-d'));
                });
            })
            ->sum('decAmount');

        return (float) $rapel;
    }

    /**
     * Show payslip for specific employee and period
     */
    public function show($periodeAwal, $periodeAkhir, $nik, $periode, $closingKe)
    {
        $closing = Closing::where('vcPeriodeAwal', $periodeAwal)
            ->where('vcPeriodeAkhir', $periodeAkhir)
            ->where('vcNik', $nik)
            ->where('periode', $periode)
            ->where('vcClosingKe', $closingKe)
            ->with(['karyawan', 'gapok', 'divisi'])
            ->first();

        if (!$closing) {
            abort(404, 'Data closing tidak ditemukan');
        }

        // Redirect ke print slip gaji
        return redirect()->route('slip-gaji.print', [
            'periodeAwal' => $periodeAwal,
            'periodeAkhir' => $periodeAkhir,
            'nik' => $nik,
            'periode' => $periode,
            'closingKe' => $closingKe
        ]);
    }

    /**
     * View Gaji - List gaji yang sudah diproses
     */
    public function viewGaji(Request $request)
    {
        $query = Closing::with(['karyawan', 'divisi', 'gapok']);

        // Filter berdasarkan periode (periode gajian)
        if ($request->filled('periode_dari')) {
            $query->where('periode', '>=', $request->periode_dari);
        }
        if ($request->filled('periode_sampai')) {
            $query->where('periode', '<=', $request->periode_sampai);
        }

        // Filter berdasarkan divisi
        if ($request->filled('divisi') && $request->divisi != 'SEMUA') {
            $query->where('vcKodeDivisi', $request->divisi);
        }

        // Filter berdasarkan NIK atau Nama (satu kolom bisa multi pencarian)
        if ($request->filled('search')) {
            $search = $request->search;
            // Split by comma atau space untuk multi pencarian
            $searchTerms = preg_split('/[,\s]+/', trim($search));

            $query->where(function ($q) use ($searchTerms) {
                foreach ($searchTerms as $term) {
                    if (!empty(trim($term))) {
                        $q->orWhere('vcNik', 'like', '%' . trim($term) . '%')
                            ->orWhereHas('karyawan', function ($qq) use ($term) {
                                $qq->where('Nama', 'like', '%' . trim($term) . '%');
                            });
                    }
                }
            });
        }

        $records = $query->orderBy('periode', 'desc')
            ->orderBy('vcKodeDivisi', 'asc')
            ->orderBy('vcNik', 'asc')
            ->paginate(50);

        // Ambil data periode sebelumnya untuk setiap record
        $recordsWithPrevious = [];
        foreach ($records as $record) {
            $periodeSebelumnya = null;

            // Jika closing ke-2, ambil closing ke-1 dengan periode yang sama
            if ($record->vcClosingKe == '2') {
                $periodeSebelumnya = Closing::where('vcNik', $record->vcNik)
                    ->where('periode', $record->periode)
                    ->where('vcClosingKe', '1')
                    ->first();
            }
            // Jika closing ke-1, ambil closing ke-2 dari periode sebelumnya
            elseif ($record->vcClosingKe == '1') {
                $periodeSebelumnya = Closing::where('vcNik', $record->vcNik)
                    ->where('periode', '<', $record->periode)
                    ->where('vcClosingKe', '2')
                    ->orderBy('periode', 'desc')
                    ->first();
            }

            $recordsWithPrevious[] = [
                'record' => $record,
                'periode_sebelumnya' => $periodeSebelumnya,
            ];
        }

        $divisis = Divisi::orderBy('vcKodeDivisi')->get();

        return view('proses.view-gaji.index', compact('records', 'recordsWithPrevious', 'divisis'));
    }
}
