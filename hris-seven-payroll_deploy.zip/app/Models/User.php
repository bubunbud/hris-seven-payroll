<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'nik',
        'role',
        'is_active',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
        'is_active' => 'boolean',
    ];

    /**
     * Relasi ke Karyawan berdasarkan NIK
     */
    public function karyawan()
    {
        return $this->belongsTo(Karyawan::class, 'nik', 'Nik');
    }

    /**
     * Relasi many-to-many dengan Role (sistem baru)
     */
    public function roles()
    {
        return $this->belongsToMany(Role::class, 'user_role');
    }

    /**
     * Check apakah user memiliki role tertentu (backward compatibility dengan kolom role)
     */
    public function hasRole($role)
    {
        return $this->roles()->where(function ($query) use ($role) {
            $query->where('slug', $role)
                ->orWhere('name', $role);
        })->exists();
    }

    /**
     * Check apakah user memiliki salah satu dari roles yang diberikan
     */
    public function hasAnyRole(array $roles)
    {
        return $this->roles()->where(function ($query) use ($roles) {
            $query->whereIn('slug', $roles)
                ->orWhereIn('name', $roles);
        })->exists();
    }

    /**
     * Check apakah user memiliki permission tertentu
     */
    public function hasPermission($permissionSlug)
    {
        if ($this->isAdmin()) {
            return true;
        }

        $hasPermission = $this->roles()->whereHas('permissions', function ($query) use ($permissionSlug) {
            $query->where('slug', $permissionSlug);
        })->exists();

        if ($hasPermission) {
            return true;
        }
        return false;
    }

    /**
     * Check apakah user memiliki salah satu dari permissions yang diberikan
     */
    public function hasAnyPermission(array $permissionSlugs)
    {
        if ($this->isAdmin()) {
            return true;
        }

        $hasPermission = $this->roles()->whereHas('permissions', function ($query) use ($permissionSlugs) {
            $query->whereIn('slug', $permissionSlugs);
        })->exists();

        if ($hasPermission) {
            return true;
        }
        return false;
    }

    /**
     * Check apakah user adalah admin (backward compatibility)
     */
    public function isAdmin()
    {
        return $this->hasRole('admin');
    }

    /**
     * Check apakah user adalah HR (backward compatibility)
     */
    public function isHR()
    {
        return $this->hasRole('hr');
    }

    /**
     * Check apakah user adalah manager (backward compatibility)
     */
    public function isManager()
    {
        return $this->hasRole('manager');
    }
}
